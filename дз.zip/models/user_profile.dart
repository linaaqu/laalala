class UserProfile {
  final String firstName;
  final String lastName;
  final int age;
  final String hobby;
  final String emoji;

  UserProfile({
    required this.firstName,
    required this.lastName,
    required this.age,
    required this.hobby,
    required this.emoji,
  });

  String get fullName => '$firstName $lastName';
}