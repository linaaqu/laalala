import 'package:flutter/material.dart';
import '../models/user_profile.dart';

class ProfileFormScreen extends StatefulWidget {
  const ProfileFormScreen({super.key});

  @override
  State<ProfileFormScreen> createState() => _ProfileFormScreenState();
}

class _ProfileFormScreenState extends State<ProfileFormScreen> {
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _ageController = TextEditingController();
  final _hobbyController = TextEditingController();
  final _emojiController = TextEditingController();

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _ageController.dispose();
    _hobbyController.dispose();
    _emojiController.dispose();
    super.dispose();
  }

  void _saveProfile() {
    if (_firstNameController.text.isEmpty) return;
    if (_lastNameController.text.isEmpty) return;
    if (_ageController.text.isEmpty) return;
    if (_hobbyController.text.isEmpty) return;
    if (_emojiController.text.isEmpty) return;
    
    final age = int.tryParse(_ageController.text);
    if (age == null) return;

    final profile = UserProfile(
      firstName: _firstNameController.text,
      lastName: _lastNameController.text,
      age: age,
      hobby: _hobbyController.text,
      emoji: _emojiController.text,
    );
    Navigator.pop(context, profile);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Создание профиля'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              controller: _firstNameController,
              decoration: const InputDecoration(
                labelText: 'Имя',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _lastNameController,
              decoration: const InputDecoration(
                labelText: 'Фамилия',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _ageController,
              decoration: const InputDecoration(
                labelText: 'Возраст',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _hobbyController,
              decoration: const InputDecoration(
                labelText: 'Хобби',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _emojiController,
              decoration: const InputDecoration(
                labelText: 'Эмодзи',
                border: OutlineInputBorder(),
                hintText: '😋 🍉 🌸',
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveProfile,
              child: const Text(
                'Сохранить профиль',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}