import 'package:flutter/material.dart';
import 'profile_form_screen.dart';
import '../models/user_profile.dart';
import '../widgets/profile_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  UserProfile? _userProfile;

  void _openProfileForm() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const ProfileFormScreen(),
      ),
    ).then((result) {
      if (result != null && result is UserProfile) {
        setState(() {
          _userProfile = result;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Профиль пользователя'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_userProfile != null)
              ProfileCard(profile: _userProfile!)
            else
              const Text(
                'Профиль ещё не создан',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _openProfileForm,
              child: const Text(
                'Создать профиль',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}